
Optimized Graphic Presets for Kingdom Come Deliverance by OVNI
==============================================================

- Better performances and/or quality.
- Added options in advanced graphics menu.
- "Instant boost" hotkeys (meant to give a *temporary* boost in demanding areas)


Compatibility
=============

- Requires game's version 1.3.1 or +
- Not compatible with mods that modify "Graphic Settings" or "Advanced Graphics settings" menus.


Installation / Update
=====================

- If you installed pre v3.x.x versions of this mod before, remove it first (cf Removal section).
(You only need to do this once. You don't need to do it for each updates)

- Download "kcd_optimized_graphic_presets" and extract its content directly in game's root folder (eg: "C:\Program Files (x86)\Steam\steamapps\common\KingdomComeDeliverance")
Overwrite files if asked (it will only overwrite previous versions of this mod)


Limitations
===========

The "basic' graphics settings menu can only set texture to medium quality. Use advanced graphics menu to change it.


Removal
=======

Download 'ogp_uninstall.bat' from optional files and run it from game root folder
(eg: "C:\Program Files (x86)\Steam\steamapps\common\KingdomComeDeliverance")


Hotkeys
=======

d = ensure game runs in native fullscreen
Numpad 0 = instant boost off
Numpad 1 = instant boost on


FAQ / TROUBLESHOOTING
=====================

**Q: How to override OGP settings ?**
To override OGP settings, write your console commands within Mods\optimized_graphic_presets\ogp_override.cfg
(I chose this filename over user.cfg so it won't cause issue for users with an old user.cfg from an outdated OGP version)

**Q: How to fix "blocky pixels" ?**
Set an higher global illumination setting, or choose "baked".

**Q: How to disable native fullscreen auto-switch ?**
Delete Mods\optimized_graphic_presets\Data\force_native_fullscreen.pak

**Q: How to disable hotkeys ?**
Delete Mods\optimized_graphic_presets\Data\hotkeys.pak

**Q: Why does advanced settings menu have "Controls" title ?**
It's the only way to display more buttons in the menu.


ChangeLog
=========

3.6.0
- MOD: better perf for volumetric fog (~6% more fps compared to previous setting)
- MOD: enabled volfog for high and ultra global presets

3.5.0
- NEW: 'ogp_override.cfg' is executed after loading/applying ogp settings.

3.4.0
- NEW: Replaced profile switch hotkeys in favor of an "instant boost" on(np1) and off (np0) hotkeys
- NEW: Enhanced (better looking) volumetric fog (disabled by default).
- MOD: Optimized weather profile: rain costs ~3% FPS less and drops are smaller.
- MOD: Added choice for the 3 vanilla weather profiles
- MOD: Reduced water choices to only one (other choices cost up to 5% FPS more without any visual difference).
- MOD: Increased object view distance for medium preset
- MOD: Right arrow key now enforces native fullscreen (just like D) for left-handers.
- FIX: Texture button's value is now always correct.

3.3.0
- NEW/FIX: Texture settings is now correctly applied (also fixes "texture setting stuck at lowest" bug)
- MOD: Simplified menu: no more confirmations. Makes flowSHARTs a bit less unmanageable... Plus actionscript behavior isn't the same in every menu anyway...
- MOD: When changing profile in the basic settings menu, texture is always set to medium. WONFIX (it would only lead to flowSHARTs chaos...), use advanced settings to change it.
- MOD: improved grass settings (increased grass-terrain color bending distance)

3.2.1
- FIX: Reset settings as they were where leaving adv settings menu without saving changes.
- FIX: Force LOD system to refresh sooner, in main menu ("Reload the game, I get washed (blur) background" bug)

3.2.0
- NEW: Save settings when leaving Simple Graphic Menu
- NEW: Added SMAA T2x without subsampling as flicker-free AA option
- MOD: SMAA2TxSS uses x3 subsampling (was x2 previously)
- FIX: "Loaded settings overridden by vanilla ones"
- FIX: 3 points lightning setting actual value / gui value mismatch
- FIX: clamp button choices, so buttons wont get an arbitrary value when there's no choice corresponding to cvar's value (eg: ogp_set_physics -5 made menu show Physics: Ugly instead of Medium (the highest choice) )
- FIX: ogp_set_cvar does not try to assign positive values to inexistent xxx_vanilla cvar (was causing inconstant sys_spec_ogp_dof_state value)
- FIX: "no sunshafts even when r_sunshafts=1"
- FIX: ambient occlusion typo
- FIX: removed false-alarm error log when setting custom profile from (simple) graphic setting menu.

3.1.0
- FIX: "Settings aren't saved" issue on Windows10
- FIX: ogp_set_3pl console command now works (to apply 3point lightning settings)
- MOD: Settings are now loaded from lua instead of flowgraph
- MOD: Removed ogp_setup.bat (symb link no longer needed)

3.0.2
- FIX: 75, 95, 100 fov settings

3.0.1
- FIX: Misleading outdated error message in ogp_setup.bat

3.0.0
- NEW: Shadows use highest lod (makes lod transition smoother a little)
- NEW: Can set all-in-one profile in (standard) graphic menu.
- NEW: Can change sub-profiles in advanced graphic menu
- NEW: Settings load/saving from user profile
- NEW: In adv Graphic Menu, disabled DoF and vignette effect to see applied changes.
- NEW: Adv Graphic Menu contains 13 options instead of 7
- NEW: in Adv Graphic Menu, Apply does not require confirmation.
- NEW: more SSDO presets (old one is "strong").
- NEW: Unlimited range for rainy/wet terrain shader (practically free, and the seam looked weird).
- NEW: Added baked GI setting, replaces GI off (which made barns and interiors pitch black).
- NEW: Extended FOV choices
- NEW: texture sub-profile with consistent anisotropic values.
- NEW: drunk sharpening on/off
- NEW: 3PL on/off
- NEW: grass wind on/off
- NEW: DoF on/off
- MOD: Hotkeys are set using lua to avoid using user.cfg (also mod.cfg is broken...)
- MOD: Decoupled some settings (AA, motionblur, grass wind, etc.) from profiles so they can be set on their own.
- MOD: Reduced GI flickering even more.
- MOD: GI Settings closer to vanilla look (except baked).
- MOD: Kept only shadows settings with best quality/cost ratio, reduced flickering with lower setting.
- MOD: Redone grass, traded distance for fewer pop-in.
- FIX: "ugly preset crashing game"
- FIX: "Ultra preset typos"
- FIX: "heads disappearing using ugly preset"

2.3
- BUGFIX commented vsync off in user.cfg
- BUGFIX typo ( \`e_UberlodDistanceRatio )
- BUGFIX fixed "ugly preset crashing game" issue
- top-level profiles are now cfg files instead of var groups.
- always use e_svoti_ResScaleBase=0, modify e_svoti_LowSpecMode instead.
- added missing ultra preset for shading
- added missing ultra preset for GI
- e_ViewDistMin=40 instead of 50 for ultra
- removed e_UberlodActivate from var groups (had no effect there)
- added e_UberlodActivate in user.cfg
- reduced svoTI saturation
- added more commented tweaks in user.cfg
- replaced readme.txt by README.md

2.21
- bugfix highest preset uses highest settings (ultra was the same as high except for lod)
- shadow presets : r_ShadowCastingLightsMaxCount 0/10/15/20/25 instead of 3 for all (caused shadow flickering because engine looks to randomly pick light...)
- moved d and esc hotkey to user.cfg (so user can disable them)
- increased e_ViewDistMin for low and medium lod presets

2.2
- hopefully fixed blackface
- fixed some shadow flickering
- added CVarGroups to revert vanilla settings for each categories.
- disabled r_VolumetricFogSunLightCorrection (effect only visible if volfog enabled).
- reduced max shadow sources to 3 (should improve perfs vs npcs with torches)
- ugly presets is less ugly (enabled grass-terrain color blending + ssdo + less obvious grass popup), costs ~5% FPS more.
- added a new profile (low had became too heavy)
- increased ssdo str, reduced min radius (so shadow-less glass looks better).
- non-ugly presets use r_AntialiasingTAAPattern (better subsampling)

2.1
- bugfix: low grass preset disabling trees shadows
- shadows settings improvement

2.0
- Added multiple CVarGroups
- Does not reset every settings (physics, etc.)
- All presets use higher rendering quality (better normal mapping / POM / etc.)
- GI cascade lod 5 instead of 4 (vanilla was 2) to reduce flickering even more and marginally increase framerate.
- GI settings should hopefully no longer generate black eyes
- Tweaked shadows for each preset.
- Tweaked grass for each preset.
- Added hotkeys to switch individual sub-presets
- Reduced preset number to only 4 (was 5).

1.31
fixed black eyes

1.3
- interiors are darker (than presets v1.2, it's still a bit brighter than vanilla tho)
- increased ambient occlusion amount
- fixed black eyes
- ugly now show grass (very few)
- ugly now always use lowest lod models
- low preset is faster (should be on pair with vanilla low preset)

1.21
minor global illumination settings tweaks

1.2
- disabled global illumination for ugly presets. As a result you will have to use torches more often but the fps boost is quite huge.
- made the "dark blocks"  less visible without impacting framerate too much. (may even boost quality for higher preset in the future)
- doubled the amount of cascades for GI, so it stop flickering due to resolution being to low.
- added hotkeys to change presets
- d key enables native fullscreen

1.1
disabled motionblur
